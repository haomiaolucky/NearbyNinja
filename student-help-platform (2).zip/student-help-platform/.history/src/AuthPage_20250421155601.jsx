import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { CardContent } from "@/components/ui/cardContent";

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const toggleForm = () => setIsLogin(!isLogin);

  return (
    <div className="min-h-screen flex items-center justify-center bg-blue-50">
      <Card className="w-full max-w-md p-6 shadow-xl">
        <CardContent>
          <h2 className="text-2xl font-bold text-center mb-6">
            {isLogin ? "登录" : "注册"}到小朋友互助平台
          </h2>
          <form className="space-y-4">
            {!isLogin && (
              <Input placeholder="用户名" type="text" required />
            )}
            <Input placeholder="邮箱" type="email" required />
            <Input placeholder="密码" type="password" required />
            <Button className="w-full mt-2">{isLogin ? "登录" : "注册"}</Button>
          </form>
          <p className="text-center text-sm text-gray-600 mt-4">
            {isLogin ? "还没有账号？" : "已有账号？"}
            <button
              onClick={toggleForm}
              className="text-blue-500 ml-2 hover:underline"
            >
              {isLogin ? "注册" : "登录"}
            </button>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
